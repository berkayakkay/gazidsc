for i in range (10):
if i %1 == 0:
print(i)
[9]